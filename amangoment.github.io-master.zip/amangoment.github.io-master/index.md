<div class="navbar">
  <div class="navbar-inner">
      <ul class="nav">
          <li><a href="{{ BASE_PATH }}/assets/amango_cv.pdf">cv</a></li>
          <li><a href="https://github.com/amangoment">github</a></li>
          <li><a href="https://crackfit.github.io/">blog</a></li>
          <li><a href="https://twitter.com/amangoment">@amangoment</a></li>
      </ul>
  </div>
</div>

<table class="wide">

</table>

<div class="navbar">
  <div class="navbar-inner">
      <ul class="nav">
          <li><a href="morefigs.html">see more figures</a></li>
      </ul>
  </div>
</div>
