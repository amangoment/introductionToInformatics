---
layout: page
title: about
description: Mange Chen is junior undergraduate student in the School of Informatics and Computing at Indiana University Bloomington; research in machine learning and security
---

Mange Chen is junior undergraduate student in the
[School of Informatics and Computing](https://www.soic.indiana.edu)
at the Indiana University Bloomington;
research in machine learning and security.

[curriculum vitae ![CV as pdf](icons16/pdf-icon.png)]({{ BASE_PATH }}/assets/amango_cv.pdf)

[orcid](http://orcid.org): [0000-0003-1889-0614](http://orcid.org/0000-0003-1889-0614)

[impactstory page](https://impactstory.org/u/0000-0002-4914-6671)

---

<div class="container">
<h4><a name="contact"></a>contact</h4>

    <div class="row-fluid">
        <div class="span5">
            Mange Chen<br/>
            <a href="https://www.soic.indiana.edu">School of Informatics and Computing</a><br/>
            <a href="https://www.indiana.edu/">Indiana University Bloomington</a><br/>
            <a href="http://map.iu.edu/iub/?ctrx=-9631763.5&ctry=4745384.5&level=20">Lindley Hall</a><br/>
            150 S. Woodlawn Ave.<br/>
            Bloomington, IN 47405<br/>
            USA<br/><br/>

            Email: <a href="mailto:amangoment@gmail.com">amangoment@gmail.com</a>
            Phone: 812-369-0754
        </div>
    </div>
</div>
